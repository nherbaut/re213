var struct_s_o_a_p___e_n_v_____reason =
[
    [ "SOAP_ENV__Reason", "struct_s_o_a_p___e_n_v_____reason.html#a48023c7ac8459f5c1bac7f327429d5c3", null ],
    [ "~SOAP_ENV__Reason", "struct_s_o_a_p___e_n_v_____reason.html#a9bb4b0c6fa87734a287e6f36554d177e", null ],
    [ "soap_type", "struct_s_o_a_p___e_n_v_____reason.html#a0f45e39424e50eabd0b723c503fd7f15", null ],
    [ "soap_type", "struct_s_o_a_p___e_n_v_____reason.html#a0f45e39424e50eabd0b723c503fd7f15", null ],
    [ "SOAP_ENV__Text", "struct_s_o_a_p___e_n_v_____reason.html#ab6a4a9406b12259b556f4b4348cfe9b6", null ]
];